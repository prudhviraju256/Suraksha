package com.example.project

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.project.ui.theme.ProjectTheme

class TrainingDetailsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val title = intent.getStringExtra("title") ?: "Training"

        setContent {
            ProjectTheme {
                TrainingDetailsUI(title)
            }
        }
    }
}

@Composable
fun TrainingDetailsUI(title: String) {

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {

        Text(title, style = MaterialTheme.typography.headlineSmall)

        Spacer(modifier = Modifier.height(10.dp))

        Text("Description:", style = MaterialTheme.typography.titleMedium)

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            "This training explains disaster safety, emergency handling, and practical awareness techniques. It includes real-life scenarios and drills."
        )

        Spacer(modifier = Modifier.height(20.dp))

        Text("Images:", style = MaterialTheme.typography.titleMedium)

        Spacer(modifier = Modifier.height(10.dp))

        Image(
            painter = painterResource(id = R.drawable.img1),
            contentDescription = "",
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp)
        )

        Spacer(modifier = Modifier.height(10.dp))

        Image(
            painter = painterResource(id = R.drawable.img2),
            contentDescription = "",
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp)
        )

        Spacer(modifier = Modifier.height(10.dp))

        Image(
            painter = painterResource(id = R.drawable.img3),
            contentDescription = "",
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp)
        )
    }
}