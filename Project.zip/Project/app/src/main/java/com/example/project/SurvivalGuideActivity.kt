package com.example.project

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import com.example.project.ui.theme.ProjectTheme

class SurvivalGuideActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            ProjectTheme {
                SurvivalGuideScreen()
            }
        }
    }
}

@Composable
fun SurvivalGuideScreen(modifier: Modifier = Modifier) {

    var selectedDisaster by remember {
        mutableStateOf("")
    }

    val disasters = listOf(
        "Avalanche",
        "Cold Wave",
        "Cyclone",
        "Drought",
        "Earthquakes",
        "Fire",
        "Floods",
        "Gas and Chemical Leakages",
        "Thunderstorm",
        "Landslide",
        "Forest Fire",
        "Lightning",
        "Tsunami",
        "Urban Floods",
        "Heat Wave",
        "Smog / Air Pollution",
        "Biological Emergencies",
        "Nuclear Radiological Emergencies"
    )

    if (selectedDisaster.isEmpty()) {

        Column(
            modifier = modifier
                .fillMaxSize()
                .background(Color(0xFFF2F2F2))
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {

            Spacer(modifier = Modifier.height(30.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {

                IconButton(
                    onClick = { }
                ) {

                    Icon(
                        Icons.Default.ArrowBack,
                        contentDescription = null,
                        tint = Color.Black
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    "Dos & Don'ts",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(30.dp))

            disasters.forEach { item ->

                Text(
                    text = item,

                    fontSize = 22.sp,

                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            selectedDisaster = item
                        }
                        .padding(vertical = 24.dp)
                )
            }
        }

    } else {

        ColdWaveGuideScreen(
            title = selectedDisaster,
            onClose = {
                selectedDisaster = ""
            }
        )
    }
}

@Composable
fun ColdWaveGuideScreen(
    title: String,
    onClose: () -> Unit
) {

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFEAEAEA))
            .verticalScroll(rememberScrollState())
            .padding(
                start = 16.dp,
                end = 16.dp,
                top = 16.dp,
                bottom = 90.dp
            ),

        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Spacer(modifier = Modifier.height(20.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),

            colors = CardDefaults.cardColors(
                containerColor = Color.White
            ),

            shape = RoundedCornerShape(0.dp)
        ) {

            Column(
                modifier = Modifier.padding(18.dp)
            ) {

                Text(
                    text = title,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF1F3B57),
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )

                Spacer(modifier = Modifier.height(14.dp))

                HorizontalDivider()

                Spacer(modifier = Modifier.height(20.dp))

                // DO'S
                Text(
                    "Do's",
                    color = Color(0xFF0A8F08),
                    fontSize = 26.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )

                Spacer(modifier = Modifier.height(20.dp))

                DosDontRow(
                    "🧥",
                    "Keep yourself dry, wear woollen clothes."
                )

                DosDontRow(
                    "🏠",
                    "Stay indoors."
                )

                DosDontRow(
                    "☕",
                    "Drink hot fluid regularly."
                )

                Spacer(modifier = Modifier.height(24.dp))

                // DON'TS
                Text(
                    "Don'ts",
                    color = Color.Red,
                    fontSize = 26.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )

                Spacer(modifier = Modifier.height(20.dp))

                DosDontRow(
                    "🚫",
                    "Do not burn coal indoors."
                )

                DosDontRow(
                    "❌",
                    "Do not massage the frostbitten area."
                )

                DosDontRow(
                    "⚠️",
                    "Do not ignore shivering."
                )

                Spacer(modifier = Modifier.height(24.dp))

                HorizontalDivider()

                Spacer(modifier = Modifier.height(24.dp))

                // BEFORE
                SectionTitle("Before")

                BulletPoint(
                    "Have adequate winter clothing. Multiple layers of clothing is also useful."
                )

                BulletPoint(
                    "Have emergency supplies ready."
                )

                Spacer(modifier = Modifier.height(24.dp))

                // DURING
                SectionTitle("During")

                BulletPoint(
                    "Stay indoors as much as possible, minimise travel to prevent exposure to cold wind."
                )

                BulletPoint(
                    "Keep dry. If wet, change clothes quickly to prevent loss of body heat."
                )

                BulletPoint(
                    "Prefer mittens over gloves; mittens provide more warmth and insulation from cold."
                )

                BulletPoint(
                    "Listen to radio, watch TV, read newspapers for weather updates."
                )

                BulletPoint(
                    "Drink hot drinks regularly."
                )

                BulletPoint(
                    "Don't drink alcohol. It reduces your body temperature."
                )

                BulletPoint(
                    "Take care of elderly people and children."
                )

                BulletPoint(
                    "Store adequate water as pipes may freeze."
                )

                BulletPoint(
                    "Watch out for symptoms of frostbite like numbness, white or pale appearance on fingers, toes, ear lobes and the tip of the nose."
                )

                BulletPoint(
                    "Do not massage the frostbitten area. This can cause more damage."
                )

                BulletPoint(
                    "Put the areas affected by frostbite in warm — not hot — water."
                )

                BulletPoint(
                    "Do not ignore shivering. It is an important first sign that the body is losing heat."
                )

                Spacer(modifier = Modifier.height(24.dp))

                // HYPOTHERMIA
                SectionTitle("In the case of Hypothermia")

                BulletPoint(
                    "Get the person into a warm place and change his/her clothes."
                )

                BulletPoint(
                    "Warm the person's body with skin-to-skin contact, blankets, clothes, towels or sheets."
                )

                BulletPoint(
                    "Give warm drinks to help increase body temperature. Do not give alcohol."
                )

                BulletPoint(
                    "Seek medical attention if the condition worsens."
                )

                Spacer(modifier = Modifier.height(30.dp))

                Button(
                    onClick = {
                        onClose()
                    },

                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .width(180.dp)
                        .height(55.dp),

                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF1976D2)
                    ),

                    shape = RoundedCornerShape(10.dp)
                ) {

                    Icon(
                        Icons.Default.ArrowBack,
                        contentDescription = null,
                        tint = Color.White
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    Text(
                        "BACK",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun DosDontRow(
    emoji: String,
    text: String
) {

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),

        verticalAlignment = Alignment.CenterVertically
    ) {

        Text(
            emoji,
            fontSize = 40.sp
        )

        Spacer(modifier = Modifier.width(16.dp))

        Text(
            text,
            fontSize = 18.sp
        )
    }
}

@Composable
fun SectionTitle(title: String) {

    Column {

        Text(
            title,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Black
        )

        Spacer(modifier = Modifier.height(12.dp))
    }
}

@Composable
fun BulletPoint(text: String) {

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),

        verticalAlignment = Alignment.Top
    ) {

        Text(
            "🟢",
            fontSize = 16.sp
        )

        Spacer(modifier = Modifier.width(10.dp))

        Text(
            text,
            fontSize = 18.sp
        )
    }
}