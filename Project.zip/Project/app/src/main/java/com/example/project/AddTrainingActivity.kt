package com.example.project

import android.app.Activity
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.Image
import android.graphics.Bitmap
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts

import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.project.ui.theme.ProjectTheme

class AddTrainingActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ProjectTheme {
                AddTrainingScreen()
            }
        }
    }
}
@Composable
fun AddTrainingScreen() {

    val context = LocalContext.current

    var title by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var participants by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var capturedImage by remember {
        mutableStateOf<Bitmap?>(null)
    }
    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->

        if (result.resultCode == Activity.RESULT_OK) {

            val bitmap = result.data
                ?.extras
                ?.get("data") as? Bitmap

            if (bitmap != null) {
                capturedImage = bitmap
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF2F4F7))
    ) {

        // 🔵 TOP BAR
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp)
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF1E88E5), Color(0xFF1565C0))
                    )
                )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 40.dp, start = 16.dp, end = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {

                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    IconButton(
                        onClick = {
                            (context as? android.app.Activity)?.finish()
                        }
                    ) {

                        Icon(
                            Icons.Default.ArrowBack,
                            contentDescription = "",
                            tint = Color.White
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    Text(
                        "Add Training",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // 📄 FORM CARD
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .offset(y = (-40).dp),
            shape = RoundedCornerShape(20.dp),
            elevation = CardDefaults.cardElevation(8.dp)
        ) {

            Column(modifier = Modifier.padding(16.dp)) {

                // TITLE
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Training Title") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // DATE
                OutlinedTextField(
                    value = date,
                    onValueChange = { date = it },
                    leadingIcon = { Icon(Icons.Default.CalendarToday, null) },
                    label = { Text("Date") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // LOCATION
                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it },
                    leadingIcon = { Icon(Icons.Default.LocationOn, null) },
                    label = { Text("Location") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // CATEGORY
                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Category (Flood / Fire / Earthquake)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // PARTICIPANTS
                OutlinedTextField(
                    value = participants,
                    onValueChange = { participants = it },
                    leadingIcon = { Icon(Icons.Default.Person, null) },
                    label = { Text("No. of Participants") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )
                Spacer(modifier = Modifier.height(10.dp))

// DESCRIPTION
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },

                    label = { Text("Description") },

                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp),

                    shape = RoundedCornerShape(12.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))

// 📷 CAMERA BUTTON
                Button(
                    onClick = {

                        try {

                            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)

                            launcher.launch(intent)

                        } catch (e: Exception) {

                            Toast.makeText(
                                context,
                                "Camera not available",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    },

                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),

                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFFF9800)
                    ),

                    shape = RoundedCornerShape(12.dp)
                ) {

                    Icon(
                        Icons.Default.CameraAlt,
                        contentDescription = null,
                        tint = Color.White
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    Text(
                        "ADD PHOTO",
                        color = Color.White
                    )
                }
                Spacer(modifier = Modifier.height(20.dp))

                // ✅ SUBMIT BUTTON
                Button(
                    onClick = {

                        if (
                            title.isEmpty() ||
                            date.isEmpty() ||
                            location.isEmpty() ||
                            category.isEmpty() ||
                            participants.isEmpty() ||
                            description.isEmpty()
                        ) {
                            Toast.makeText(context, "Please fill all fields", Toast.LENGTH_SHORT).show()
                        } else {

                            val sharedPreferences =
                                context.getSharedPreferences(
                                    "training_data",
                                    android.content.Context.MODE_PRIVATE
                                )

                            sharedPreferences.edit()
                                .putString("title", title)
                                .putString("participants", participants)
                                .apply()

                            Toast.makeText(
                                context,
                                "Training Added Successfully ✅",
                                Toast.LENGTH_SHORT
                            ).show()

                            (context as? Activity)?.finish()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E88E5)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("SUBMIT", color = Color.White)
                }
            }
        }
    }
}