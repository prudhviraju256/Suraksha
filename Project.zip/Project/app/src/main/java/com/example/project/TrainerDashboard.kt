package com.example.project

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.project.ui.theme.ProjectTheme

class TrainerDashboard : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()

        setContent {
            ProjectTheme {
                TrainerDashboardUI()
            }
        }
    }
}

@Composable
fun TrainerDashboardUI() {

    val context = LocalContext.current

    var expanded by remember {
        mutableStateOf(false)
    }

    var selectedScreen by remember {
        mutableStateOf("home")
    }

    Scaffold(

        bottomBar = {

            NavigationBar(
                containerColor = Color.White
            ) {

                // HOME
                NavigationBarItem(
                    selected = selectedScreen == "home",

                    onClick = {
                        selectedScreen = "home"
                    },

                    icon = {
                        Icon(
                            Icons.Default.Home,
                            contentDescription = null
                        )
                    },

                    label = {
                        Text("Home")
                    }
                )

                // GUIDE
                NavigationBarItem(
                    selected = selectedScreen == "guide",

                    onClick = {
                        selectedScreen = "guide"
                    },

                    icon = {
                        Icon(
                            Icons.Default.MenuBook,
                            contentDescription = null
                        )
                    },

                    label = {
                        Text("Guide")
                    }
                )

                // PROFILE
                NavigationBarItem(
                    selected = selectedScreen == "profile",

                    onClick = {
                        selectedScreen = "profile"
                    },

                    icon = {
                        Icon(
                            Icons.Default.Person,
                            contentDescription = null
                        )
                    },

                    label = {
                        Text("Profile")
                    }
                )
            }
        }

    ) { paddingValues ->

        when (selectedScreen) {

            "profile" -> {
                TrainerProfileScreen(
                    modifier = Modifier.padding(paddingValues)
                )
            }

            "guide" -> {
                SurvivalGuideScreen(
                    modifier = Modifier.padding(paddingValues)
                )
            }

            else -> {

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                        .background(Color(0xFFF4F7FF))
                        .verticalScroll(rememberScrollState())
                ) {

                    // TOP SECTION
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(250.dp)
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        Color(0xFF1976D2),
                                        Color(0xFF42A5F5)
                                    )
                                )
                            )
                    ) {

                        Column {

                            // TOP BAR
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(
                                        top = 50.dp,
                                        start = 16.dp,
                                        end = 16.dp
                                    ),

                                horizontalArrangement =
                                    Arrangement.SpaceBetween,

                                verticalAlignment =
                                    Alignment.CenterVertically
                            ) {

                                IconButton(
                                    onClick = {
                                        (context as? ComponentActivity)?.finish()
                                    }
                                ) {

                                    Icon(
                                        Icons.Default.ArrowBack,
                                        null,
                                        tint = Color.White
                                    )
                                }

                                Text(
                                    "Trainer Dashboard",
                                    color = Color.White,
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.Bold
                                )

                                Row {

                                    IconButton(
                                        onClick = {

                                            context.startActivity(
                                                Intent(
                                                    context,
                                                    NotificationActivity::class.java
                                                )
                                            )
                                        }
                                    ) {

                                        Icon(
                                            Icons.Default.Notifications,
                                            null,
                                            tint = Color.White
                                        )
                                    }

                                    // MENU
                                    Box {

                                        IconButton(
                                            onClick = {
                                                expanded = true
                                            }
                                        ) {

                                            Icon(
                                                Icons.Default.MoreVert,
                                                null,
                                                tint = Color.White
                                            )
                                        }

                                        DropdownMenu(
                                            expanded = expanded,
                                            onDismissRequest = {
                                                expanded = false
                                            }
                                        ) {

                                            DropdownMenuItem(
                                                text = {
                                                    Text("Home")
                                                },
                                                onClick = {
                                                    selectedScreen = "home"
                                                    expanded = false
                                                }
                                            )

                                            DropdownMenuItem(
                                                text = {
                                                    Text("Profile")
                                                },
                                                onClick = {
                                                    selectedScreen = "profile"
                                                    expanded = false
                                                }
                                            )

                                            DropdownMenuItem(
                                                text = {
                                                    Text("Logout")
                                                },

                                                onClick = {

                                                    expanded = false

                                                    context.startActivity(
                                                        Intent(
                                                            context,
                                                            MainActivity::class.java
                                                        )
                                                    )

                                                    (context as? ComponentActivity)?.finish()
                                                }
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(25.dp))

                            // PROFILE SECTION
                            Row(
                                modifier = Modifier.padding(horizontal = 22.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {

                                Box(
                                    modifier = Modifier
                                        .size(80.dp)
                                        .clip(CircleShape)
                                        .background(Color.White),

                                    contentAlignment = Alignment.Center
                                ) {

                                    Icon(
                                        Icons.Default.Person,
                                        null,
                                        tint = Color(0xFF1976D2),
                                        modifier = Modifier.size(50.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(16.dp))

                                Column {

                                    Text(
                                        "Welcome Back 👋",
                                        color = Color.White,
                                        fontSize = 16.sp
                                    )

                                    Spacer(modifier = Modifier.height(4.dp))

                                    Text(
                                        "John Trainer",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 24.sp
                                    )

                                    Spacer(modifier = Modifier.height(4.dp))

                                    Text(
                                        "Disaster Management Expert",
                                        color = Color.White.copy(0.9f),
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }
                    }

                    // MAIN CONTENT
                    Column(
                        modifier = Modifier
                            .padding(horizontal = 16.dp)
                            .offset(y = (-40).dp)
                    ) {

                        // TRAINING SECTION
                        Card(
                            shape = RoundedCornerShape(24.dp),
                            elevation = CardDefaults.cardElevation(10.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = Color.White
                            )
                        ) {

                            Column(
                                modifier = Modifier.padding(18.dp)
                            ) {

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement =
                                        Arrangement.SpaceBetween
                                ) {

                                    Text(
                                        "Your Trainings",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp
                                    )

                                    Text(
                                        "View All",
                                        color = Color(0xFF1976D2),
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                val sharedPreferences =
                                    context.getSharedPreferences(
                                        "training_data",
                                        android.content.Context.MODE_PRIVATE
                                    )

                                val trainingTitle =
                                    sharedPreferences.getString("title", "") ?: ""

                                val trainingParticipants =
                                    sharedPreferences.getString("participants", "") ?: ""

                                TrainingItem(
                                    "Flood Awareness",
                                    "3 Mar",
                                    "25 People",
                                    bgColor = Color(0xFFE3F2FD)
                                )

                                TrainingItem(
                                    "Fire Safety",
                                    "8 Mar",
                                    "31 People",
                                    bgColor = Color(0xFFFFF3E0)
                                )

                                TrainingItem(
                                    "Evacuation Drill",
                                    "2 Mar",
                                    "32 People",
                                    bgColor = Color(0xFFE8F5E9)
                                )

                                if (trainingTitle.isNotEmpty()) {

                                    TrainingItem(
                                        trainingTitle,
                                        "New",
                                        "$trainingParticipants People",
                                        bgColor = Color(0xFFEDE7F6)
                                    )
                                }

                                Spacer(modifier = Modifier.height(20.dp))

                                Button(
                                    onClick = {

                                        context.startActivity(
                                            Intent(
                                                context,
                                                AddTrainingActivity::class.java
                                            )
                                        )
                                    },

                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(55.dp),

                                    shape = RoundedCornerShape(16.dp),

                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFF1976D2)
                                    )
                                ) {

                                    Icon(Icons.Default.Add, null)

                                    Spacer(modifier = Modifier.width(8.dp))

                                    Text(
                                        "Add New Training",
                                        fontSize = 16.sp
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        // TRAINER DETAILS
                        Card(
                            shape = RoundedCornerShape(24.dp),

                            colors = CardDefaults.cardColors(
                                containerColor = Color.White
                            ),

                            elevation = CardDefaults.cardElevation(8.dp)
                        ) {

                            Column(
                                modifier = Modifier.padding(18.dp)
                            ) {

                                Text(
                                    "Trainer Details",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = Color(0xFF1976D2)
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                DetailRow("👤", "Name", "John Trainer")
                                DetailRow("📅", "Experience", "5 Years")
                                DetailRow("🎯", "Specialization", "Disaster Management")
                                DetailRow("📍", "Location", "India")
                            }
                        }
                    }
                }
            }
        }
    }
}



@Composable
fun TrainerProfileScreen(modifier: Modifier = Modifier) {

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF4F7FF))
            .padding(20.dp),

        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Spacer(modifier = Modifier.height(40.dp))

        Box(
            modifier = Modifier
                .size(120.dp)
                .clip(CircleShape)
                .background(Color(0xFF1976D2)),

            contentAlignment = Alignment.Center
        ) {

            Icon(
                Icons.Default.Person,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(70.dp)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            "John Trainer",
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            "Disaster Management Expert",
            color = Color.Gray
        )

        Spacer(modifier = Modifier.height(30.dp))

        val context = LocalContext.current

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp)
        ) {

            Column(
                modifier = Modifier.padding(20.dp)
            ) {

                DetailRow("📧", "Email", "trainer@gmail.com")
                DetailRow("📞", "Phone", "+91 9876543210")
                DetailRow("📍", "Location", "India")
                DetailRow("🏆", "Experience", "5 Years")

                Spacer(modifier = Modifier.height(30.dp))

                Button(

                    onClick = {

                        val sharedPreferences =
                            context.getSharedPreferences(
                                "login_data",
                                android.content.Context.MODE_PRIVATE
                            )

                        sharedPreferences.edit().clear().apply()

                        context.startActivity(
                            Intent(
                                context,
                                MainActivity::class.java
                            )
                        )

                        (context as? ComponentActivity)?.finish()
                    },

                    modifier = Modifier
                        .fillMaxWidth()
                        .height(55.dp),

                    shape = RoundedCornerShape(14.dp),

                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.Red
                    )

                ) {

                    Icon(
                        Icons.Default.Logout,
                        contentDescription = null,
                        tint = Color.White
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    Text(
                        "Logout",
                        color = Color.White,
                        fontSize = 16.sp
                    )
                }
            }
        }
    }
}

@Composable
fun DetailRow(
    emoji: String,
    title: String,
    value: String
) {

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),

        verticalAlignment = Alignment.CenterVertically
    ) {

        Text(emoji, fontSize = 20.sp)

        Spacer(modifier = Modifier.width(12.dp))

        Column {

            Text(
                title,
                fontSize = 12.sp,
                color = Color.Gray
            )

            Text(
                value,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun TrainingItem(
    title: String,
    date: String,
    people: String,
    bgColor: Color
) {

    val context = LocalContext.current

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clickable {

                val intent =
                    Intent(
                        context,
                        TrainingDetailsActivity::class.java
                    )

                intent.putExtra("title", title)

                context.startActivity(intent)
            },

        shape = RoundedCornerShape(18.dp),

        colors = CardDefaults.cardColors(
            containerColor = bgColor
        )
    ) {

        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),

            horizontalArrangement =
                Arrangement.SpaceBetween,

            verticalAlignment =
                Alignment.CenterVertically
        ) {

            Column {

                Text(
                    title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    date,
                    color = Color.Gray,
                    fontSize = 12.sp
                )
            }

            Box(
                modifier = Modifier
                    .background(
                        Color.White,
                        RoundedCornerShape(10.dp)
                    )
                    .padding(
                        horizontal = 12.dp,
                        vertical = 6.dp
                    )
            ) {

                Text(
                    people,
                    color = Color(0xFF1976D2),
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}