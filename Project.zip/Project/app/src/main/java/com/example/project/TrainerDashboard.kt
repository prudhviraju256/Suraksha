package com.example.project

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.project.ui.theme.ProjectTheme

class TrainerDashboard : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ProjectTheme {
                TrainerDashboardUI()
            }
        }
    }
}

@Composable
fun TrainerDashboardUI() {

    val context = LocalContext.current
    var expanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF1F5FF))
    ) {

        // 🔵 TOP BAR
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF42A5F5), Color(0xFF1E88E5))
                    )
                )
        ) {

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 55.dp, start = 12.dp, end = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {

                // 🔙 BACK BUTTON
                IconButton(onClick = {
                    (context as? ComponentActivity)?.finish()
                }) {
                    Icon(Icons.Default.ArrowBack, "", tint = Color.White)
                }

                Text(
                    "Dashboard",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )

                Row {

                    // 🔔 NOTIFICATION
                    IconButton(onClick = {
                        context.startActivity(
                            Intent(context, NotificationActivity::class.java)
                        )
                    }) {
                        Icon(Icons.Default.Notifications, "", tint = Color.White)
                    }

                    // ⋮ MENU
                    Box {
                        IconButton(onClick = { expanded = true }) {
                            Icon(Icons.Default.MoreVert, "", tint = Color.White)
                        }

                        DropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Home") },
                                onClick = { expanded = false }
                            )
                            DropdownMenuItem(
                                text = { Text("Settings") },
                                onClick = { expanded = false }
                            )
                            DropdownMenuItem(
                                text = { Text("Logout") },
                                onClick = {
                                    expanded = false
                                    context.startActivity(
                                        Intent(context, MainActivity::class.java)
                                    )
                                }
                            )
                        }
                    }
                }
            }
        }

        // 📦 CONTENT
        Column(
            modifier = Modifier
                .padding(16.dp)
                .offset(y = (-40).dp)
        ) {

            // MAIN CARD
            Card(
                shape = RoundedCornerShape(22.dp),
                elevation = CardDefaults.cardElevation(10.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {

                    Text("Welcome 👋", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Manage your trainings easily", fontSize = 12.sp, color = Color.Gray)

                    Spacer(modifier = Modifier.height(14.dp))

                    Text("Your Trainings", fontWeight = FontWeight.Bold)

                    Spacer(modifier = Modifier.height(10.dp))

                    TrainingItem("Flood Awareness", "3 Mar", "25 People")
                    TrainingItem("Fire Safety", "8 Mar", "31 People")
                    TrainingItem("Evacuation Drill", "2 Mar", "32 People")

                    Spacer(modifier = Modifier.height(18.dp))

                    Button(
                        onClick = {
                            context.startActivity(
                                Intent(context, AddTrainingActivity::class.java)
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFFF9800)
                        )
                    ) {
                        Icon(Icons.Default.Add, null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Add Training", color = Color.White)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // TRAINER DETAILS
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFE3F2FD)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {

                    Text(
                        "Trainer Details",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1565C0)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text("👤 Name: John Trainer")
                    Text("📅 Experience: 5 Years")
                    Text("🎯 Specialization: Disaster Management")
                    Text("📍 Location: India")
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))
    }
}

@Composable
fun TrainingItem(title: String, date: String, people: String) {

    val context = LocalContext.current

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        shape = RoundedCornerShape(14.dp),
        onClick = {
            val intent = Intent(context, TrainingDetailsActivity::class.java)
            intent.putExtra("title", title)
            context.startActivity(intent)
        }
    ) {

        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {

            Column {
                Text(title, fontWeight = FontWeight.Bold)
                Text(date, fontSize = 12.sp, color = Color.Gray)
            }

            Text(people, color = Color(0xFF4CAF50))
        }
    }
}