package com.example.project

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.painterResource
import com.example.project.R
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.project.ui.theme.ProjectTheme

class DashboardActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            ProjectTheme {
                com.example.project.MainScreen()
            }
        }
    }
}

data class DistrictData(
    val name: String,
    val trainings: Int,
    val participants: Int,
    val date: String,
    val trainer: String
)
@Composable
fun MainScreen() {

    var currentScreen by remember { mutableStateOf("home") }
    var selectedReport by remember { mutableStateOf<DistrictData?>(null) }

    when (currentScreen) {

        "home" -> HomeScreen(
            onReportClick = { currentScreen = "district" },
            onAddTrainerClick = { currentScreen = "add" }
        )

        "district" -> DistrictScreen(
            onBack = { currentScreen = "home" },
            onItemClick = {
                selectedReport = it
                currentScreen = "detail"
            }
        )

        "detail" -> DetailScreen(
            data = selectedReport,
            onBack = { currentScreen = "district" }
        )

        "add" -> AddTrainerScreen(
            onBack = { currentScreen = "home" }
        )
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onReportClick: () -> Unit,
    onAddTrainerClick: () -> Unit
) {

    var expanded by remember { mutableStateOf(false) }

    val totalTrainings = 102
    val totalParticipants = "5K"

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("DashBoard") },

                navigationIcon = {
                    IconButton(onClick = { expanded = true }) {
                        Icon(Icons.Default.Menu, null)
                    }

                    DropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        DropdownMenuItem(text = { Text("Home") }, onClick = { expanded = false })
                        DropdownMenuItem(text = { Text("Settings") }, onClick = { expanded = false })
                    }
                },

                actions = {
                    IconButton(onClick = {}) {
                        Icon(Icons.Default.Notifications, null)
                    }
                }
            )
        },

        bottomBar = {
            NavigationBar {

                NavigationBarItem(
                    selected = true,
                    onClick = {},
                    icon = { Icon(Icons.Default.Home, null) },
                    label = { Text("Dashboard") }
                )

                NavigationBarItem(
                    selected = false,
                    onClick = { onAddTrainerClick() },
                    icon = { Icon(Icons.Default.Add, null) },
                    label = { Text("Add Trainer") }
                )

                NavigationBarItem(
                    selected = false,
                    onClick = { onReportClick() },
                    icon = { Icon(Icons.Default.Assessment, null) },
                    label = { Text("Report") }
                )
            }
        }

    ) { paddingValues ->

        Column(
            modifier = Modifier
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
        ) {

            // HEADER
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(70.dp)
                    .background(Color.Blue),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "WELCOME ADMIN",
                    color = Color.White,
                    style = MaterialTheme.typography.headlineLarge
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                "Total Trainings",
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 16.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(100.dp)
                        .background(Color(0xFF2196F3)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.School, null, tint = Color.White)
                        Text("$totalTrainings", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("Trainings", color = Color.White)
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(100.dp)
                        .background(Color(0xFFFF9800)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Group, null, tint = Color.White)
                        Text(totalParticipants, color = Color.White, fontWeight = FontWeight.Bold)
                        Text("Participants", color = Color.White)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // REPORT BOX
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(70.dp)
                    .padding(horizontal = 16.dp)
                    .background(Color.LightGray)
                    .clickable { onReportClick() },
                contentAlignment = Alignment.Center
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("District Wise Report", fontWeight = FontWeight.Bold)
                    Icon(Icons.Default.ArrowForward, null)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                "Overview of today's training",
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 16.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // STATIC GRAPH
            TrainingBarChart()

            Spacer(modifier = Modifier.height(10.dp))

            // EXPORT BUTTON
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(70.dp)
                    .padding(16.dp)
                    .background(Color(0xFF1976D2)),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.FileDownload, null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("EXPORT DATA", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // ADMIN DETAILS
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .background(Color(0xFFE3F2FD))
                        .padding(16.dp)
                ) {
                    Text("Admin Details", fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Name: Rajesh Pullipate")
                    Text("Age: 32")
                    Text("Location: Punjab, Amritsar")
                    Text("Education: 10+2")
                }
            }
        }
    }
}

@Composable
fun AddTrainerScreen(onBack: () -> Unit) {

    var name by remember { mutableStateOf("") }
    var mobile by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var gender by remember { mutableStateOf("") }
    var age by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }

    var qualification by remember { mutableStateOf("") }
    var specialization by remember { mutableStateOf("") }
    var experience by remember { mutableStateOf("") }
    var organization by remember { mutableStateOf("") }

    var showSuccess by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Spacer(modifier = Modifier.height(20.dp))
        Text(
            text = "Add Trainer",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(16.dp))

        // 🎯 BASIC DETAILS
        Text("Basic Trainer Details", fontWeight = FontWeight.Bold)

        OutlinedTextField(name, { name = it }, label = { Text("Full Name") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(mobile, { mobile = it }, label = { Text("Mobile Number") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(email, { email = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(gender, { gender = it }, label = { Text("Gender") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(age, { age = it }, label = { Text("Age") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(address, { address = it }, label = { Text("Address (City, State)") }, modifier = Modifier.fillMaxWidth())

        Spacer(modifier = Modifier.height(16.dp))

        // 🎯 PROFESSIONAL DETAILS
        Text("Professional Details", fontWeight = FontWeight.Bold)

        OutlinedTextField(qualification, { qualification = it }, label = { Text("Qualification") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(specialization, { specialization = it }, label = { Text("Specialization") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(experience, { experience = it }, label = { Text("Experience (Years)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(organization, { organization = it }, label = { Text("Previous Organization") }, modifier = Modifier.fillMaxWidth())

        Spacer(modifier = Modifier.height(20.dp))

        // ✅ SUBMIT BUTTON
        Button(
            onClick = {
                showSuccess = true
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Submit")
        }

        Spacer(modifier = Modifier.height(10.dp))

        // ✅ SUCCESS MESSAGE
        if (showSuccess) {
            Text(
                text = "Details Submitted Successfully ✅",
                color = Color(0xFF2E7D32),
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(8.dp)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // BACK BUTTON
        OutlinedButton(
            onClick = { onBack() },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Back")
        }
    }
}

@Composable
fun TrainingBarChart() {

    val labels = listOf("Flood", "Fire", "Earthquake", "Cyclone", "Landslides")
    val values = listOf(80f, 50f, 60f, 40f, 40f)

    val maxValue = 100f

    Row(
        modifier = Modifier
            .height(250.dp)
            .padding(16.dp)
    ) {

        Column(
            verticalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxHeight()
        ) {
            listOf("100", "80", "60", "50", "40", "20", "0").forEach { Text(it) }
        }

        Spacer(modifier = Modifier.width(8.dp))

        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.Bottom
        ) {

            val colors = listOf(
                Color(0xFF4CAF50),
                Color(0xFFFF5722),
                Color(0xFF2196F3),
                Color(0xFFFFC107),
                Color(0xFF9C27B0)
            )

            values.forEachIndexed { index, value ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .width(30.dp)
                            .fillMaxHeight(value / maxValue)
                            .background(colors[index])
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(labels[index])
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DistrictScreen(
    onBack: () -> Unit,
    onItemClick: (DistrictData) -> Unit
) {

    var searchQuery by remember { mutableStateOf("") }
    var selectedDate by remember { mutableStateOf("") }
    var showDatePicker by remember { mutableStateOf(false) }

    val districts = listOf(
        DistrictData("Amritsar", 25, 1200, "01/06/2026", "Rajesh"),
        DistrictData("Ludhiana", 18, 950, "05/06/2026", "Amit"),
        DistrictData("Jalandhar", 22, 1100, "10/06/2026", "Kiran"),
        DistrictData("Patiala", 15, 700, "15/06/2026", "Ravi"),
        DistrictData("Mohali", 20, 850, "20/06/2026", "Suresh")
    )

    // FILTER
    val filtered = districts.filter {
        it.name.contains(searchQuery, true) &&
                (selectedDate.isEmpty() || it.date == selectedDate)
    }

    // DATE PICKER
    if (showDatePicker) {
        val state = rememberDatePickerState()

        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    showDatePicker = false
                    selectedDate = state.selectedDateMillis?.let {
                        java.text.SimpleDateFormat("dd/MM/yyyy")
                            .format(java.util.Date(it))
                    } ?: ""
                }) { Text("OK") }
            }
        ) {
            DatePicker(state = state)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Monthly Report") },
                navigationIcon = {
                    IconButton(onClick = { onBack() }) {
                        Icon(Icons.Default.ArrowBack, null)
                    }
                }
            )
        }
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {

            // 🔍 SEARCH
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Search District") },
                modifier = Modifier.fillMaxWidth(),
                leadingIcon = { Icon(Icons.Default.Search, null) }
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 📅 DATE PICKER
            OutlinedTextField(
                value = selectedDate,
                onValueChange = {},
                label = { Text("Select Date") },
                modifier = Modifier.fillMaxWidth(),
                trailingIcon = {
                    IconButton(onClick = { showDatePicker = true }) {
                        Icon(Icons.Default.DateRange, null)
                    }
                },
                readOnly = true
            )

            Spacer(modifier = Modifier.height(16.dp))

            // LIST
            filtered.forEach {

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp)
                        .clickable { onItemClick(it) },
                    elevation = CardDefaults.cardElevation(4.dp)
                ) {

                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(it.name, fontWeight = FontWeight.Bold)
                        Text("Date: ${it.date}")
                        Text("Participants: ${it.participants}")
                    }
                }
            }
        }
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(
    data: DistrictData?,
    onBack: () -> Unit
) {

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Training Details") },
                navigationIcon = {
                    IconButton(onClick = { onBack() }) {
                        Icon(Icons.Default.ArrowBack, null)
                    }
                }
            )
        }
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {

            data?.let {

                Text(it.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)

                Spacer(modifier = Modifier.height(10.dp))

                // 👤 TRAINER DETAILS (NO TRAINING TEXT)
                Text("Trainer Name: ${it.trainer}")
                Text("Date: ${it.date}")
                Text("Participants: ${it.participants}")

                Spacer(modifier = Modifier.height(16.dp))

                Text("Description", fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    """
1. This training program focused on disaster preparedness and safety awareness.
2. Trainers explained real-life emergency handling techniques.
3. Participants were actively engaged in practical demonstrations.
4. Awareness sessions were conducted for local communities.
5. Safety drills were performed under expert supervision.
6. First aid techniques were taught in detail.
7. Emergency evacuation plans were demonstrated.
8. Risk assessment strategies were discussed.
9. Feedback was collected from all participants.
10. Overall training was successful and impactful.
                    """.trimIndent()
                )

                Spacer(modifier = Modifier.height(20.dp))

                // 🖼️ IMAGES (VERTICAL - PERFECT ALIGNMENT)
                Image(
                    painter = painterResource(R.drawable.img1),
                    contentDescription = null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Image(
                    painter = painterResource(R.drawable.img2),
                    contentDescription = null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Image(
                    painter = painterResource(R.drawable.img3),
                    contentDescription = null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                )
            }
        }
    }
}